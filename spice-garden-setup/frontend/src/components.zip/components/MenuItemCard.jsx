import { Link } from "react-router-dom";
import { useCart } from "../context/CartContext";
import { useToast } from "../context/ToastContext";
import SpiceMeter from "./SpiceMeter";
import VegBadge from "./VegBadge";

const API_ORIGIN =
  import.meta.env.VITE_API_URL?.replace(/\/api\/?$/, "") ||
  "http://127.0.0.1:8000";

function getImageUrl(image) {
  if (!image) {
    return "";
  }

  // Django API already returned a full URL
  if (image.startsWith("http://") || image.startsWith("https://")) {
    return image;
  }

  // Django returned a relative media path
  return `${API_ORIGIN}${image.startsWith("/") ? "" : "/"}${image}`;
}

const menuCardStyles = `
  .menu-card-modern {
    display: block;
    overflow: hidden;
    height: 100%;
    color: inherit;
    text-decoration: none;
    background: #fff;
    border: 1px solid #dedede;
    border-radius: 10px;
    box-shadow: 0 3px 12px rgba(0, 0, 0, 0.05);
  }

  .menu-card-modern-image {
    width: 100%;
    height: 175px;
    overflow: hidden;
    border-bottom: 1px solid #e5e5e5;
    background: #fafafa;
  }

  .menu-card-modern-image img {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  .menu-card-modern-placeholder {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 55px;
  }

  .menu-card-modern-body {
    padding: 13px;
  }

  .menu-card-modern-top {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 6px;
    min-height: 22px;
    margin-bottom: 8px;
  }

  .menu-card-modern-body h3 {
    margin: 0 0 6px;
    font-size: 15px;
    line-height: 1.35;
  }

  .menu-card-modern-desc {
    display: -webkit-box;
    min-height: 38px;
    margin: 0 0 11px;
    overflow: hidden;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    font-size: 12px;
    line-height: 1.55;
    opacity: 0.76;
  }

  .menu-card-modern-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    padding-top: 10px;
    border-top: 1px solid #e7e7e7;
  }

  .menu-card-modern-price {
    font-size: 17px;
    font-weight: 700;
    white-space: nowrap;
  }

  .menu-card-modern-add {
    min-height: 35px;
    padding: 7px 10px;
    font-size: 12px;
    white-space: nowrap;
  }

  @media (max-width: 560px) {
    .menu-card-modern-image {
      height: 165px;
    }

    .menu-card-modern-body {
      padding: 12px;
    }
  }
`;

export default function MenuItemCard({ item }) {
  const { addItem } = useCart();
  const { showToast } = useToast();

  function handleAdd(e) {
    e.preventDefault();
    e.stopPropagation();
    addItem(item, 1);
    showToast(`${item.name} added to cart`);
  }

  const imageUrl = getImageUrl(item.image);

  return (
    <>
      <style>{menuCardStyles}</style>

      <Link
        to={`/menu/${item.id}`}
        className="menu-card-modern"
      >
        <div className="menu-card-modern-image">
          {imageUrl ? (
            <img
              src={imageUrl}
              alt={item.name}
              loading="lazy"
            />
          ) : (
            <div className="menu-card-modern-placeholder">
              🍛
            </div>
          )}
        </div>

        <div className="menu-card-modern-body">
          <div className="menu-card-modern-top">
            <VegBadge isVeg={item.is_veg} />
            <SpiceMeter level={item.spice_level} />
          </div>

          <h3>{item.name}</h3>

          <p className="menu-card-modern-desc">
            {item.description || ""}
          </p>

          <div className="menu-card-modern-footer">
            <span className="menu-card-modern-price">
              ₹{Number(item.price).toFixed(0)}
            </span>

            <button
              type="button"
              className="btn btn-secondary menu-card-modern-add"
              onClick={handleAdd}
            >
              Add to Cart
            </button>
          </div>
        </div>
      </Link>
    </>
  );
}
